package game.moves;

import game.Game;
import game.Player;

/**
 * Created by thibautdebroca on 12/11/2017.
 */
public interface Move {

    boolean isValidMove(Game game, Player player);

    void playMove(Game game, Player player);
}
